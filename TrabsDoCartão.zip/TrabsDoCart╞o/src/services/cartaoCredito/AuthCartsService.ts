
import { compare } from "bcryptjs";
import { sign } from "jsonwebtoken";


import p from "../../../prisma";


import env from "../../variaveis";
interface AuthRequest {
  num_cartao: string;
  cvv: string;
}

class AuthCartsService {
  async execute({ num_cartao, cvv }: AuthRequest) {
    const cartaoCredito = await p.cartao.findFirst({
      where: {
        num_cartao: num_cartao,
      },
    });

    if (!cartaoCredito) {
      throw new Error("deu erro! Usuário ou cvv incorretos.");
    }

    const cvvMatch = await compare(cvv, cartaoCredito.cvv);

    if (!cvvMatch) {
      throw new Error("cvv incorreta");
    }

    const token = sign(
      {
        num_cartao: cartaoCredito.num_cartao,
        cvv: cartaoCredito.cvv,
      },
      env.JWT_SECRET,
      {
        subject: cartaoCredito.id,
        expiresIn: "30d",
      }
    );

    return {
      id: cartaoCredito.id,
      num_cartao: cartaoCredito.num_cartao,
      cvv: cartaoCredito.cvv,
      token: token,
    };
  }
}

export { AuthCartsService };

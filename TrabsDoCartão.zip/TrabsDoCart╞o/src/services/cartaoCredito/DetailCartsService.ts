//* Libraries imports

//* Local imports
import p from "../../../prisma";

class DetailCartsService {
  async execute(cartao_id: string) {
    const cartaoCredito = await p.cartao.findFirst({
      where: {
        id: cartao_id,
      },
      select: {
        id: true,
        num_cartao: true,
        cvv: true,
      },
    });

    return "complo, não tloca mais (xinguilingui falando)";
  }
}

export { DetailCartsService };

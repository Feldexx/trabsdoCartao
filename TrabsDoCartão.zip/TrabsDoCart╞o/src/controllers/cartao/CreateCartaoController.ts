//* Libraries imports
import { Request, Response } from "express";

//* Local imports
import { CreateCartsService } from "../../services/cartaoCredito/CreateCartsService";

class CreateCartaoController {
  async handle(req: Request, res: Response) {
    const { nome_titular, num_cartao, cvv, senha } = req.body;

    const createCartaoCreditoService = new CreateCartsService();
    const cartao = await createCartaoCreditoService.execute({
      nome_titular,
      num_cartao,
      cvv,
      senha,
    });

    return res.json(cartao);
  }
}

export { CreateCartaoController };

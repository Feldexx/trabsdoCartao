//* Libraries imports
import { Request, Response } from "express";

//* Local imports
import { AuthCartsService } from "../../services/cartaoCredito/AuthCartsService";

class AuthCartaoController {
  async handle(req: Request, res: Response) {
    const { num_cartao, cvv } = req.body;

    const authCartaoService = new AuthCartsService();

    const auth = await authCartaoService.execute({
      num_cartao,
      cvv,
    });

    return res.json(auth);
  }
}

export { AuthCartaoController };
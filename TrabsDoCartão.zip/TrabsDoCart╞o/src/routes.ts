
import { Router } from "express";


import { Autenticacao } from "./middlewares/Autenticacao";


import { DetailCartaoController} from "../src/controllers/cartao/DetailCartaoController";
import { CreateCartaoController } from "../src/controllers/cartao/CreateCartaoController";
import { AuthCartaoController } from "../src/controllers/cartao/AuthCartaoController";

const router = Router();

router.post("/cartaoCredito", new CreateCartaoController().handle);
router.post("/validaCartaoCredito", new  AuthCartaoController().handle);
router.get(
  "/cartaoCreditoToken",
  Autenticacao,
  new DetailCartaoController().handle
);

export { router };

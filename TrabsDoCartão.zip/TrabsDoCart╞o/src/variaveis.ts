
import z from "zod";
import dotenv from "dotenv";

const { JWT_SECRET } = dotenv.config().parsed || {};
const JWT_SECRET_SCHEMA = z.string().nonempty();
if (!JWT_SECRET) throw new Error("JWT_SECRET error");

const env = {
  JWT_SECRET: JWT_SECRET_SCHEMA.parse(JWT_SECRET),
};

export default env;
